# Detection  > 2025-04-04 2:14am
https://universe.roboflow.com/label-tm0w0/detection-azd53

Provided by a Roboflow user
License: CC BY 4.0

